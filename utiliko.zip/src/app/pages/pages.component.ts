import { Component, AfterViewInit } from '@angular/core';

@Component({
  selector: 'app-starter',
  templateUrl: './pages.component.html',
  styleUrls: ['./pages.component.scss']
})
export class PagesComponent implements AfterViewInit {
  ngAfterViewInit() {}
}
